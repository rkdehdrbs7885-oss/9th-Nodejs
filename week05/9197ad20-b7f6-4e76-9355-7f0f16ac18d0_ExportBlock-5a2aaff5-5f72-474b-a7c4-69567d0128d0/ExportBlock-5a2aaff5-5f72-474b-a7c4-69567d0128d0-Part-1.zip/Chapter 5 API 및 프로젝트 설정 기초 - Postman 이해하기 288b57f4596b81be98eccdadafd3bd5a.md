# Chapter 5. API 및 프로젝트 설정 기초 - Postman 이해하기

<aside>
<img src="https://www.notion.so/icons/list_gray.svg" alt="https://www.notion.so/icons/list_gray.svg" width="40px" /> **목차**

</aside>

## 🔄 API 테스트하기

우리는 보통 API를 테스트할 때에는 `curl`과 같은 도구를 주로 이용합니다. 터미널에서 API 요청을 호출해볼 수 있는 CLI 도구입니다.

아래는 `curl` 을 사용한 API 테스트입니다.

```bash
curl -X POST "http://localhost:3000/api/v1/users/signup" \
  -H "content-type: application/json" \
  -d '{
  "email": "test@example.com",
  "name": "엘빈",
  "gender": "남성",
  "birth": "2000-02-03",
  "address": "주소1",
  "detailAddress": "세부주소1",
  "phoneNumber": "010-1234-1234",
  "preferences": [1, 2, 5]
}'
```

VSCode에서 간단한 HTTP 요청을 바로 실행할 수 있어 편리하지만, CLI 기반이기 때문에 명령어를 알고 있어야 테스트가 가능하다는 점에서 다소 어렵습니다😶‍🌫️!

## 👨 Postman

~~(man이니까 남자 이모지로..)~~

**Postman**은 API를 설계, 빌드, 테스트 및 반복할 수 있는 API 플랫폼입니다.

![image.png](image%2022.png)

Postman은 위 이미지와 같이 GUI 기반이기에, 쿼리스트링, Authorization이나 Header, Body 값을 수정하여 요청할 수 있고,  응답도 JSON, XML 같은 데이터도 보기 좋게 포맷팅해서 보여주어서, **한눈에 파악하기 편합니다!**

![요로코롬 쉽고 편하게 메서드도 변경할 수 있답니다!](image%2023.png)

요로코롬 쉽고 편하게 메서드도 변경할 수 있답니다!

> **Postman 설치는 아래 레퍼런스를 참고해주세요!**
> 

[Windows/MacOS에서 Postman 다운로드 및 설치하는 방법](https://apidog.com/kr/blog/download-install-postman-2/)

## 🔧 Postman 요청 설정 화면

Postman을 설치하고 실행하면, 아래와 같은 탭을 확인할 수 있어요!

![image.png](image%2024.png)

각 탭이 어떤 역할을 하는지 간단하게 알아볼까요? 😁

### **1️⃣ Params (쿼리 파라미터 설정)**

![image.png](image%2025.png)

- URL에 추가되는 **쿼리스트링(Query String) 값을 설정**하는 곳입니다.

![image.png](image%2026.png)

- 이미지처럼 **key-value 구조**로 이루어져 있으며, URL에서는 `?id=1` 형태로 표시됩니다!

### **2️⃣ Authorization (인증 설정)**

- API 요청 시 필요한 **인증 방식**을 설정합니다.
- 입력한 **토큰 값이 자동으로 헤더(Headers)에 추가됩니다.**

---

### **3️⃣ Headers (HTTP 헤더 설정)**

- HTTP 요청에 포함될 **헤더(Header) 정보를 설정합**니다.
- 보통 **Content-Type, Authorization, Accept 등**의 정보를 추가합니다.
- Authorization 탭에서 설정한 값도 자동으로 여기 포함됩니다.
- **예시**:
    
    ```
    Content-Type: application/json
    Authorization: Bearer TOKEN값jerrysleeptired
    ```
    

---

### **4️⃣ Body (요청 본문)**

- **POST, PUT, PATCH 요청**을 보낼 때 **데이터를 담아 보내는 곳입니다**.
- **GET 요청**에는 값을 조회하는 메서드이기에, Body가 필요하지 않습니다!
- JSON, XML, form-data 등의 형식으로 데이터 전송 가능합니다.
- **예시** (JSON):
    
    ```json
    {
      "name": "제리",
      "email": "제리@swu.ac.kr"
    }
    ```
    

---

### **5️⃣ Scripts (스크립트 실행)**

- 요청을 보내기 **전(Pre-request Scripts)** 또는 **후(Tests)** 실행할 스크립트를 작성합니다.
- 보통 **테스트 자동화, 변수 설정, 응답 데이터 검증** 등에 사용됩니다!

---

### **6️⃣ Settings (설정)**

- 요청을 보낼 때 적용할 다양한 **환경 설정**을 변경합니다.
- 예를 들어, 자동 리디렉션 허용, 요청 시간 초과 설정 등을 변경할 수 있습니다!

<aside>
🚀

자, Postman에 대해서 알았으니, 우리가 개발할 API를 **직접 테스트해볼 일만 남았습니다!** 

이제 본격적으로 API를 개발해봅시다! 🔥🔥

</aside>