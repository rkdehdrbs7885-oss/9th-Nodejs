# Chapter 2. 실전 SQL- 어떤 Query를 작성해야 할까?

![1주차 워크북의 ERD](image%2010.png)

1주차 워크북의 ERD

우선 아래의 요구 사항에 대해 어떻게 데이터를 줄지 고민해봅시다.

<aside>
🔑 ***책이 받은 좋아요 개수를 보여준다.***

</aside>

만약, **책 테이블에 좋아요 개수를 둔다면** 아래와 같은 query로 충분하겠죠

```sql
select likes from book;
```

그런데, 만약 **likes 칼럼없이 집계**를 한다면 아래와 같은 query가 필요합니다

```sql
select count(*) from book_likes where book_id = {대상 책 아이디};
```

위의 요구 사항에서 추가로 아래와 같은 요구 사항이 생긴다면 어떻게 해야 할까요?

<aside>
🔑 ***책의 좋아요 갯수를 계산하는데, 내가 차단한 사용자의 좋아요는 집계를 하지 않는다.***

</aside>

![                                                                차단 테이블](image%2011.png)

                                                                차단 테이블

우선 차단 테이블이 위와 같다고 해봅시다.

그러면 아래와 같은 쿼리가 필요하게 됩니다.

*책의 아이디가 3, 내 아이디가 2라고 가정합시다!*

```sql
select count(*) from book_likes where book_id = 3
	and user_id not in (select target_id from block where owner_id = 2);
```

위의 쿼리문을 아래와 같은 **left join**을 사용하도록 변경이 가능합니다.

```sql
select count(*)
from book_like as bl
left join block as b on bl.user_id = b.target_id and b.owner_id = 2
where bl.book_id = 3 and b.target_id is null;
```

<aside>
🗣 **참고!**

저 같은 경우, join 연산보다는 **sub query가 더 가독성이 좋다고 생각**해
sub query를 자주 사용합니다!

**원하는 스타일의 query를 선택하여 사용**하시면 될 것 같습니다.

</aside>

그리고 제가 굳이 차단에 대한 요구 사항을 예시로 든 이유는

<aside>
🌟 **TIP)**

***커뮤니티 성격의 app의 경우 신고, 차단 기능이 없을 경우 reject를 받아 런칭이 안됩니다.***

</aside>

따라서 처음에 쿼리를 간단하게 작성했다가 reject를 고려해 모든 쿼리를 수정했던
좋지 않은 경험을 했기에,

여러분들에게 처음부터 아예 신고, 차단을 고려하여 쿼리를 작성 하는 것을 추천 드립니다.

만약 기획이 나오지 않았다면 PM에게 상황을 설명하며 요청을 하시기 바랍니다.

이처럼 이번 주차는 **실제로 접할 수 있는 요구 사항들에 대해 어떻게 접근할지**
몇 가지 예시를 보여 드리겠습니다.

## 실제로 접할 수 있는 요구 사항

---

### *해시태그를 통한 책의 검색*

쿼리를 작성 할 때 N : M 관계로 인해 가운데 매핑 테이블이 추가 된 경우는
쉬운 쿼리로 데이터를 가져오기가 힘듭니다.

***UMC***라는 이름을 가진 해시태그가 붙은 책을 찾도록 해봅시다.

**(DataBase에 #을 붙여서 저장하거나 아니면 # 없이 저장하는 것은 프론트 개발자 분과 상의를 해서 결정을 해야 하고 저 같은 경우는 저번 프로젝트에서 후자로 했기에 후자로 예시를 드리겠습니다.)**

이 역시 직감적으로 조인 연산 혹은 서브 쿼리가 필요함을 느낄 수 있죠

```sql
select * from book where id in 
	(select book_id from book_hash_tag 
			where hash_tag_id  = (select id from hash_tag where name = 'UMC' ));
```

이 쿼리는 다시 아래처럼 join 연산을 사용하도록 변경이 가능합니다.

```sql
select b.*
from book as b
inner join book_hash_tag as bht on b.id = bht.book_id
inner join hash_tag as ht on bht.hash_tag_id = ht.id
where ht.name = 'UMC';
```

자, 이제 책들의 목록을 최신 순으로 조회하는 쿼리를 만들어 봅시다.

간단하게 아래와 같이 만들 수 있겠죠?

편의를 위해 모든 데이터를 다 가져온다고 합시다.

```sql
select * from book order by created_at desc;
```

자, 이번에는 조금 더 어렵게 좋아요 개수 순으로 목록 조회를 한다고 해봅시다.

book 자체에 likes 칼럼이 없기에 단순한 select로는 조회가 안됩니다.

```sql
select * from book as b 
join (select count(*) as like_count
				 from book_likes
						group by book_id) as likes on b.id = likes.book_id
order by likes.like_count desc;
```

이런 형태의 쿼리를 통해 인기 순 정렬이 가능해집니다.