# Chapter 2. 실전 SQL- SQL과 페이지네이션

## 페이징(Paging)

---

### 🤔 목록 조회, 이대로 괜찮을까요?

사실 목록 조회는 저렇게만 하면 안됩니다.

예를 들어 책이 100만 권이 있다고 할 때, 저 쿼리를 그대로 사용하게 된다면 

엄청난 렉이 발생하게 되겠죠, 한번에 100만 개를 다 가져오게 되니…😱

따라서 Database자체에서 끊어서 가져오는 것이 필요하고 이를
***paging* 이라고 합니다.**

Paging에도 사실 **2가지 형태**가 존재합니다.

### Offset based 페이징

이는 우리가 자주 봤던 페이징 입니다.

![Untitled](Untitled%204.png)

이렇게 직접 페이지 번호를 찾아내어 이동하는 페이징이죠.

그러면 저런 쿼리는 어떻게 만들까요?

paing 쿼리는 sql마다 상이하며 **UMC는 다시 한 번 말하지만 mysql 기반으로 합니다!**

```sql
select *
from book
order by likes desc
limit 10 offset 0;
```

위와 같이 limit를 통해 한 페이지에서 보여줄 데이터의 개수를 정하고

offset으로 몇 개를 **건너뛸지를 정합니다**.

그러면 아래와 같이 추론이 가능하죠.

**페이지 x번에 대하여 한 페이지에 y개를 보여준다**면

```sql
select * 
from book
order by likes desc
limit y offset(x - 1) * y;
```

이렇게 쿼리를 만들 수 있겠죠?

**왜 (x - 1)이냐면 보통 1페이지가 첫 페이지이기 때문이죠!**

이제 offset paging을 적용해서 위의 목록 조회 query를 만들어 봅시다!

페이지 n번에 대해 한번에 15개씩 보여준다고 합시다.

```sql
select * from book
order by created_at desc
limit 15 offset (n - 1) * 15;
```

**당연히 (n - 1) * 15 이렇게 쿼리에 적으면 안되고… 숫자 계산해서 넣어야 합니다..**

이제 다음으로 인기 순 정렬에 대한 쿼리를 만들어 봅시다.

```sql
select * from book as b
join (select count(*) as like_count
				 from book_likes 
					group by book_id) as likes on b.id = likes.book_id
order by likes.like_count desc
limit 15 offset (n - 1) * 15;
```

### Offset paging의 단점

offset paging은 직접 여러 개의 데이터를 넘어가서 가져온다는 느낌이기에
페이지가 뒤로 갈수록 넘어가는 데이터가 많아져 성능 상의 이슈가 있고,

결정적으로 **아래와 같은 문제 상황이 발생**할 수 있습니다.

<aside>
⚠️ ***사용자가 1 페이지에서 2 페이지로 넘어가려는 찰나, 게시글 6개가 추가가 되었다.***

</aside>

이러면 어떻게 될까요??

🥲 ***분명 2 페이지로 왔는데 1 페이지에서 봤던 게 또 보이네??*** 🥲

이런 단점을 보완한 페이징 기법이 있습니다.

---

### Cursor based 페이징

cursor paging의 경우 이름에서 유추 할 수 있듯이 커서로 무언가를 가르켜 페이징을 하는 방법입니다.

여기서 커서는? ***마지막으로 조회한 콘텐츠입니다.***

<aside>
📢 **마지막으로 조회한 대상 그 다음부터 가져와!**

</aside>

이렇게 생각하면 됩니다.

이제 cursor paing 쿼리의 예시를 보여드릴게요.

cursor paging은 조금 더 어렵습니다. (파이팅!)

마지막으로 조회한 책의 좋아요가 20이라면 (물론 예시여서 좋아요 칼럼이 있다고 한 거에요!)

```sql
select * from book where book.likes < 20 order by likes desc limit 15;
```

이런 형태이며 실제로는 저렇게 보다는 마지막으로 조회한 책의 아이디를 가져와서

```sql
select * from book where book.likes < 
		(select likes from book where id = 4)
			order by likes desc limit 15;
```

이런 형태의 쿼리가 됩니다.

이제 책 목록 조회 쿼리를 커서 페이징으로 해보겠습니다.

```sql
select * from book where created_at < 
	(select created_at from book where id = 3)
		order by created_at desc limit 15;
```

이번에는 인기순 커서 페이징 입니다.

```sql
select * from book as b
	 join (select count(*) as like_count 
					from book_likes 
						group by book_id) as likes on b.id = likes.book_id
			where likes.like_count < (select count(*) from book_likes where book_id = 3)
				order by likes.like_count desc limit 15;
```

<aside>
🤔 **❗질문❗**

이 인기 순 커서 페이징 쿼리가 과연 **잘 작동할까요?** 

</aside>

**아뇨,**

<aside>
🔥 이유는, 예를 들어 **좋아요가 0개인 게시글이 400개**이고,
**공교롭게 마지막으로 조회한 책의 좋아요가 0개**라면,
그리고 **아직 뒤에 조회를 하지 않은 책**이 있다면

**다음 페이지에 책이 목록으로 조회가 될까요?**

</aside>

***이런 경우가 있기에 인기 순 정렬 같이 같은 값이 있을 수 있는 경우***

***정렬 기준이 하나 더 있어야 합니다.***

따라서 위의 예시에서 좋아요 수가 같을 경우 PK값을 정렬 기준을 추가해보겠습니다.

```sql
select * from book as b
	 join (select count(*) as like_count 
						from book_likes
							group by book_id) as likes on b.id = likes.book_id
			where likes.like_count < (select count(*) from book_likes where book_id = 3)
				order by likes.like_count desc, b.id desc limit 15;
```

이러면 성공 한 걸까요?

이 경우 에도 정렬 기준이 추가 된것 일 뿐

좋아요 갯수가 같은 book이 15개가 넘어가면 그 이상의 것은 무시가 됩니다.

둘의 조건을 한번에 분류할 수 있는 기준이 필요합니다.

밑에 것은 두 조건을 한번에 cursor 값으로 지정할 수 있는 코드입니다.

좋아요 갯수와, id를 하나의 문자열로 엮어서 cursor 값이 완전히 고유한 값이라고 볼 수 있습니다. (MySQL을 기준으로 썼고 SQL마다 문법이 조금씩 다를 수 있습니다.) (10자리를 기준으로 엮은 것이고 더 길어질 수도 있습니다.)

```sql
SELECT b.*,
       CONCAT(LPAD(likes.like_count, 10, '0'), LPAD(b.id, 10, '0')) AS cursor_value
FROM book AS b
JOIN (SELECT book_id, COUNT(*) AS like_count
      FROM book_likes
      GROUP BY book_id) AS likes ON b.id = likes.book_id
HAVING cursor_value < (SELECT CONCAT(LPAD(like_count_sub.like_count, 10, '0'), LPAD(like_count_sub.book_id, 10, '0'))
                FROM (SELECT book_id, COUNT(*) AS like_count
                      FROM book_likes
                      GROUP BY book_id) AS like_count_sub
                WHERE like_count_sub.book_id = 3) # 여기에 cursor_value 값이 들어가면 됨.
ORDER BY likes.like_count DESC, b.id DESC
LIMIT 15;
```

- **간단한 쿼리 설명**
    
    ```sql
    JOIN (SELECT book_id, COUNT(*) AS like_count
          FROM book_likes
          GROUP BY book_id) AS likes ON b.id = likes.book_id
    ```
    
    일단 이 부분은 위에서 했던 좋아요 집계 서브쿼리입니다. 이 부분은 괜찮죠?
    
    ```sql
     CONCAT(LPAD(likes.like_count, 10, '0'), LPAD(b.id, 10, '0')) AS cursor_value
    ```
    
    이 부분이 조금 어렵게 느껴질 순 있지만  like_count와 book_id를 문자열로 이어 붙여 하나의 정렬키로 만드는 과정입니다.
    
    ex. 예를 들어 좋아요가 23이고 id가 45면 
    
    “0000000023” + “0000000045”→ “00000000230000000045” 가 되는 것이죠. 
    

cursor_value를 위해 having을 썼지만 집계 함수를 쓰지 않고 having 절을 쓰기는 조금 비효율적일 수 있으니 

where 절로 구현한다면 이렇게 할 수도 있겠네요.

```sql
SELECT b.*,
       CONCAT(LPAD(likes.like_count, 10, '0'), LPAD(b.id, 10, '0')) AS cursor_value
FROM book AS b
JOIN (SELECT book_id, COUNT(*) AS like_count
      FROM book_likes
      GROUP BY book_id) AS likes ON b.id = likes.book_id
WHERE CONCAT(LPAD(likes.like_count, 10, '0'), LPAD(b.id, 10, '0')) < 
      (SELECT CONCAT(LPAD(like_count_sub.like_count, 10, '0'), LPAD(like_count_sub.book_id, 10, '0'))
       FROM (SELECT book_id, COUNT(*) AS like_count
             FROM book_likes
             GROUP BY book_id) AS like_count_sub
       WHERE like_count_sub.book_id = 3) # 여기에 cursor_value 값이 들어가면 됨.
ORDER BY likes.like_count DESC, b.id DESC
LIMIT 15;

```

마지막 코드의 경우 실제 서버 구현 때는 cursor 값을 그대로 받는 것이 아닌 정렬 기준이 되는 값들을 받아서 cursor 값을 만들어 적용시키면 더욱 좋을 것 같습니다! (또한 PK 값은 보통 Long으로 설정되는 경우가 많으니 너무 값이 커질 수 있어서 생성 시간과 같은 것으로 해도 좋을 것 같습니다!)

마지막 커서 기반 페이지네이션 SQL문이 너무 어려워 보인다면 참고 자료에 잘 설명된 블로그 글을 첨부해놓았으니 확인바랍니다.